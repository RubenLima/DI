
package repasonhilos;

import java.io.*;
import java.net.*;

class Cliente {
	//nombre  máquina y puerto
	static final String HOST = "localhost";
	static final int PUERTO=5000;
	public Cliente( ) {
		try{
			//se crea el socket
			Socket skCliente = new Socket(HOST, PUERTO);

			//recojo flujo de datos del socket
			InputStream aux = skCliente.getInputStream();
			OutputStream aux2 = skCliente.getOutputStream();

			//asocio flujo de datos flujo de tipo DataInputStream
			DataInputStream flujo = new DataInputStream( aux );
			DataOutputStream flujo2= new DataOutputStream( aux2 );
			flujo2.writeUTF( "Conecto al servidor " );
			System.out.println( flujo.readUTF() );
			flujo2.writeUTF( "Conectado " );
			System.out.println( flujo.readUTF() );
			flujo2.writeUTF( "Hola " );
			System.out.println( flujo.readUTF() );
			flujo2.writeUTF( "Muy bien " );
			System.out.println( flujo.readUTF() );
			flujo2.writeUTF( "Adios " );
			System.out.println( flujo.readUTF() );
			flujo2.writeUTF( "Cerrando conexion " );
			
			
			//Capturamos cadena del flujo con readUTF y muestro
			System.out.println( flujo.readUTF() );
			
			//Cierro el socket
			skCliente.close();
		}catch(Exception e) {
		System.out.println( e.getMessage() );
	}
	}
public static void main(String[] arg) {
new Cliente();
}
}
